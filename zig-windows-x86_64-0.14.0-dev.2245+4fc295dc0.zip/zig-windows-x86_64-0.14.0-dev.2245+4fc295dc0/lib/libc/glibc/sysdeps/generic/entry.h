#ifndef __ASSEMBLY__
extern void _start (void) attribute_hidden;
#endif

#define ENTRY_POINT _start
